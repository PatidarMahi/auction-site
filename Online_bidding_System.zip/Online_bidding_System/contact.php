	
<?php  
 
 if(isset($_POST['Submit'])) {
  $mailto = "abhivish711@gmail.com";  //My email address
  //getting customer data
  $name = $_POST['firstname']; //getting customer name
  $fromEmail = $_POST['email_id']; //getting customer email
  $phone = $_POST['contact_no']; //getting customer Phome number
  $subject = "Contact Form"; //getting subject line from client
  $subject2 = "Confirmation: Message was submitted successfully | HMA WebDesign"; // For customer confirmation
  
  //Email body I will receive
  $message = "Cleint Name: " . $name . "\n"
  . "Phone Number: " . $phone . "\n\n"
  . "Client Message: " . "\n" . $_POST['subject'];
  
  //Message for client confirmation
//   $message2 = "Dear" . $name . "\n"
//   . "Thank you for contacting us. We will get back to you shortly!" . "\n\n"
//   . "You submitted the following message: " . "\n" . $_POST['message'] . "\n\n"
//   . "Regards," . "\n" . "- HMA WebDesign";
  
  //Email headers
  $headers = "From: " . $fromEmail; // Client email, I will receive
  $headers2 = "From: " . $mailto; // This will receive client
  
  //PHP mailer function
  
   $result1 = mail($mailto, $subject, $message, $headers); // This email sent to My address
   $result2 = mail($fromEmail, $subject2, $message2, $headers2); //This confirmation email to client
  
   //Checking if Mails sent successfully
  
   ?>
  <script>
    alert("Thank you for contacting us.");
    window.location="index.html";
  </script>
  <?php
//    if ($result1 && $result2) {
//      $success = "Your Message was sent Successfully!";
//    } else {
//      $failed = "Sorry! Message was not sent, Try again Later.";
//    }
  
 }
  
 ?>